-- Parameters are a tuple of (Hostname,)
INSERT INTO Host(hostname) VALUES (?);
