-- Parameters are a tuple of (Service, Port, Protocol)
INSERT INTO Service(name, port, protocol) VALUES (?, ?, ?);
