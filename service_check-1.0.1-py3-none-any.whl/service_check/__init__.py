import sys, os
PACKAGE_ROOT = os.path.abspath(os.path.dirname(__name__))
sys.path.append(PACKAGE_ROOT)
